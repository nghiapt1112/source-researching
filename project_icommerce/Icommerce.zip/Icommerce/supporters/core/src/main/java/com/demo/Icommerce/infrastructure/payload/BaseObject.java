package com.demo.Icommerce.infrastructure.payload;

public abstract class BaseObject {
}

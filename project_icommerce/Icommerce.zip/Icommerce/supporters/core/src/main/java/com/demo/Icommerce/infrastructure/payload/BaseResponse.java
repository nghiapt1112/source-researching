package com.demo.Icommerce.infrastructure.payload;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseResponse extends BaseObject {
}

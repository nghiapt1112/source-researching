rootProject.name = "chapter13"

include("heat-sensor-service", "sensor-gateway", "heat-api")

@ModuleGen(groupPackage = "chapter6", name = "chapter6")
package chapter6;

import io.vertx.codegen.annotations.ModuleGen;

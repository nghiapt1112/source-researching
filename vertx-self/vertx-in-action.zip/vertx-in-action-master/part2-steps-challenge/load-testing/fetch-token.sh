#!/bin/bash
http http://localhost:4000/api/v1/token \
  username="loadtesting-user" \
  password="13tm31n"

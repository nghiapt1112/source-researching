<template>
  <div id="app" class="pt-5">
    <router-view/>
  </div>
</template>
